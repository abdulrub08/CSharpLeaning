// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Permissive License.
// See http://www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
// All other rights reserved.

using System;
using System.Collections.Generic;
using System.Text;

[assembly: System.Web.UI.WebResource("AjaxControlToolkit.Compat.Timer.Timer.js", "text/javascript")]

namespace AjaxControlToolkit
{
    [ClientScriptResource(null, "AjaxControlToolkit.Compat.Timer.Timer.js")]
    public static class TimerScript
    {
    }
}