// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Permissive License.
// See http://www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
// All other rights reserved.


using System.Web.UI.WebControls;
using System.Web.UI;

using AjaxControlToolkit.Design;

namespace AjaxControlToolkit
{
    class PasswordStrengthExtenderDesigner : ExtenderControlBaseDesigner<PasswordStrength>
    {


    }
}
